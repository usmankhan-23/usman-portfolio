# ============================================================
# PRICE CO-MOVEMENT NETWORK ANALYSIS
# ============================================================
# This script analyses PBS (Pakistan Bureau of Statistics) CPI
# price data across multiple cities and years. It finds which
# grocery/daily-use items tend to rise or fall in price TOGETHER
# across different cities, then visualises those relationships
# as a network graph (items = nodes, co-movement = edges).
#
# High-level pipeline:
#   1. Load CSV data
#   2. Clean / fill missing prices
#   3. Build price-change vectors per item per city per year
#   4. Compute cosine similarity between every pair of items
#   5. Build a graph: add an edge if >= K cities agree (sim >= TAU)
#   6. Analyse centrality, stability, and category connectivity
#   7. Export CSVs + 7 charts
# ============================================================

# ── Standard library imports ──────────────────────────────────
import pandas as pd          # tabular data (DataFrames)
import numpy as np           # numerical operations / vectors
import networkx as nx        # graph creation and analysis
import matplotlib            # plotting backend
import matplotlib.pyplot as plt          # draw charts
import matplotlib.patches as mpatches   # legend colour patches
from itertools import combinations      # generate all item pairs (i, j) without repeats
import warnings              # suppress noisy runtime warnings
import os                    # file/directory checks
import sys                   # exit the script on fatal errors

# Suppress all runtime warnings so the console output stays clean
warnings.filterwarnings('ignore')

# ============================================================
# STEP 1 — LOAD THE CSV FILE
# ============================================================
print("\nFile loading")

file_name = 'data.csv'   # expected input file in the current working directory

# If the file doesn't exist, tell the user and quit immediately
# (no point running anything without data)
if not os.path.exists(file_name):
    print(f"\nFile not found — '{file_name}'")
    sys.exit(1)

print(f"  → Found: {file_name}")

# Read the entire CSV into a pandas DataFrame
data = pd.read_csv(file_name)

# Quick sanity check — how much data did we load?
print(f"  → Loaded {len(data):,} rows")
print(f"  → Columns: {list(data.columns)}")

# ============================================================
# STEP 2 — GLOBAL PARAMETERS & COLOUR PALETTE
# ============================================================
print("\nprice-change vectors (Preprocessing)")

# TAU  — cosine-similarity threshold.
#         Two items are considered "co-moving" in a city only if
#         their price-change vectors have cosine similarity >= TAU.
#         0.6 means the vectors must point in roughly the same direction
#         (prices tend to move up/down at the same time each month).
TAU = 0.6

# K — minimum number of cities that must agree on co-movement.
#      An edge is only added to the graph if at least K cities
#      independently show similarity >= TAU for that item pair.
#      This filters out coincidental, city-specific correlations.
K   = 3

# Colour map: each food/goods category gets a distinct hex colour.
# Used in network graphs and bar charts so categories are easy to spot.
CAT_COLORS = {
    'Cereals & Bread':                    '#2196F3',  # blue
    'Meat & Poultry':                     '#F44336',  # red
    'Dairy, Eggs & Fats':                 '#FF9800',  # orange
    'Fruits, Pulses & Vegetables':        '#4CAF50',  # green
    'Sugar, Condiments & Prepared Food':  '#9C27B0',  # purple
    'Clothing, Footwear & Energy':        '#00BCD4',  # cyan
    'Fuel, Transport & Misc':             '#795548',  # brown
}

# ============================================================
# STEP 3 — CLEAN / FILL MISSING PRICES
# ============================================================
# The PBS dataset sometimes has gaps (prices not reported for a
# city/item/month). We fill them so our vectors are continuous.

# Convert 'price' column to numeric; any non-numeric entry becomes NaN
data['price'] = pd.to_numeric(data['price'], errors='coerce')

# Count how many prices are missing BEFORE we fill them (for reporting)
missing_before = data['price'].isna().sum()

# Sort so that rows for the same item+city are consecutive and in
# chronological order — this is required for the forward/backward
# neighbour search below to work correctly
data = data.sort_values(['item', 'city', 'month_year']).reset_index(drop=True)

# ── Fill each missing price using its neighbours ──────────────
# Strategy (in priority order):
#   a) Average of the previous and next known price  (interpolation)
#   b) Just the previous known price                 (forward-fill)
#   c) Just the next known price                     (backward-fill)
for i in range(len(data)):
    if pd.isna(data.at[i, 'price']):                     # found a gap
        curr_group = (data.at[i, 'item'], data.at[i, 'city'])  # which item+city?

        # ── Search BACKWARDS for the nearest known price in the same group ──
        prev_val = np.nan
        for j in range(i - 1, -1, -1):
            if (data.at[j, 'item'], data.at[j, 'city']) == curr_group:
                if not pd.isna(data.at[j, 'price']):
                    prev_val = data.at[j, 'price']   # found it!
                    break
            else:
                break   # left the group — stop searching

        # ── Search FORWARDS for the nearest known price in the same group ──
        next_val = np.nan
        for j in range(i + 1, len(data)):
            if (data.at[j, 'item'], data.at[j, 'city']) == curr_group:
                if not pd.isna(data.at[j, 'price']):
                    next_val = data.at[j, 'price']   # found it!
                    break
            else:
                break   # left the group — stop searching

        # ── Apply the best available fill strategy ────────────────────────
        if not pd.isna(prev_val) and not pd.isna(next_val):
            # Both neighbours exist → interpolate (midpoint)
            data.at[i, 'price'] = round((prev_val + next_val) / 2.0, 2)
        elif not pd.isna(prev_val):
            # Only previous exists → carry it forward
            data.at[i, 'price'] = prev_val
        elif not pd.isna(next_val):
            # Only next exists → carry it backward
            data.at[i, 'price'] = next_val
        # If neither exists, the gap remains NaN (very rare edge case)

# ── Last resort: fill any remaining NaNs with the item's national
#    average price for that month (across all cities) ────────────
data['price'] = data.groupby(['item', 'month_year'])['price'].transform(
    lambda s: s.fillna(round(s.mean(), 2))
)

# Report how many gaps were filled
missing_after = data['price'].isna().sum()
print(f"  → Missing prices: {missing_before} found, {missing_before - missing_after} filled by average of previous and next")

# ============================================================
# STEP 4 — EXTRACT DIMENSIONS (items, cities, years)
# ============================================================
# Build sorted lists of all unique items and cities — these are
# used as the "universe" when iterating through pairs and building
# the graph nodes.
all_items  = sorted(data['item'].unique().tolist())
all_cities = sorted(data['city'].unique().tolist())
years      = ['Year1', 'Year2', 'Year3']   # internal labels for 2023-24 / 24-25 / 25-26

# Quick lookup: item name → its food category (used for node colours)
item_cat = dict(zip(data['item'], data['category']))

print(f"  → Items: {len(all_items)}   Cities: {len(all_cities)}   Years: {len(years)}")
print(f"  → Year labels: {sorted(data['year_label'].unique().tolist())}")

# ============================================================
# STEP 5 — BUILD PRICE-CHANGE VECTORS (one per item+city+year)
# ============================================================
# For each (year, item, city) triple, we compute a vector of
# month-to-month price *changes* (deltas).
#
# Example: prices = [10, 11, 10.5, 12]
#          deltas = [+1, -0.5, +1.5]   ← this is the vector
#
# These delta vectors capture the DIRECTION and MAGNITUDE of
# price movement each month, which is what cosine similarity
# will compare between two items.

# Initialise a nested dict: yearly_vectors[year][(item, city)] = delta array
yearly_vectors = {yr: {} for yr in years}

for yr in years:
    # Filter data to only this year's rows
    sub = data[data['year_label'] == yr].copy()

    # Get the sorted list of month labels for this year (chronological)
    months_sorted = sorted(sub['month_year'].unique())

    for item in all_items:
        # Narrow down to rows for just this item within this year
        item_data = sub[sub['item'] == item]

        # Pivot: rows = months, columns = cities, values = avg price
        # This gives us a tidy matrix of prices over time per city
        pivot = item_data.pivot_table(
            index='month_year', columns='city', values='price', aggfunc='mean')

        # Make sure all months are present in the right order;
        # fill any remaining NaN with forward-fill then backward-fill
        pivot = pivot.reindex(months_sorted).ffill().bfill()

        for city in all_cities:
            # Skip this city if it has no data for this item
            if city not in pivot.columns:
                continue

            prices = pivot[city].values.astype(float)

            # Need at least 2 price points to compute a difference
            if len(prices) < 2:
                continue

            # np.diff computes consecutive differences:  [p1-p0, p2-p1, ...]
            deltas = np.diff(prices)

            # Only store the vector if it's non-zero (a flat price line
            # carries no useful directional information for cosine similarity)
            if np.linalg.norm(deltas) > 0:
                yearly_vectors[yr][(item, city)] = deltas

    # Progress report for this year
    n_vec      = len(yearly_vectors[yr])
    sample_len = len(list(yearly_vectors[yr].values())[0]) if yearly_vectors[yr] else 0
    print(f"  → {yr}: {n_vec} vectors, each length {sample_len}")

# ============================================================
# STEP 6 — COMPUTE COSINE SIMILARITY FOR EVERY ITEM PAIR
# ============================================================
print("\ncalculating cosine similarity for all item pairs...")

def cosine_sim(v1, v2):
    """
    Cosine similarity — Project Section 4 formula:
        sim(y,c)(i,j) = v(i) · v(j) / (||v(i)|| × ||v(j)||)

    Returns a value in [-1, 1]:
        +1  → vectors are identical (prices always move together)
         0  → no linear relationship
        -1  → vectors are opposite (one goes up when the other goes down)

    Returns 0.0 if either vector is zero-norm (flat price line — no info).
    """
    n1, n2 = np.linalg.norm(v1), np.linalg.norm(v2)
    if n1 == 0 or n2 == 0:
        return 0.0      # guard against division by zero
    return float(np.dot(v1, v2) / (n1 * n2))

# pair_data stores the results for every (item_i, item_j) pair per year:
#   pair_data[yr]['count'][(i,j)]   = number of cities where sim >= TAU
#   pair_data[yr]['avg_sim'][(i,j)] = average cosine sim across all cities
pair_data = {}

for yr in years:
    vectors = yearly_vectors[yr]
    pc  = {}   # "passing city" count per pair
    pa  = {}   # "average similarity" per pair

    # Total number of unique item pairs (order doesn't matter)
    n_pairs = len(all_items) * (len(all_items) - 1) // 2
    print(f"  → {yr}: {n_pairs} pairs × {len(all_cities)} cities...")

    # combinations(all_items, 2) generates every unique (item_i, item_j) pair
    # without repetition — e.g. (flour, milk) but not (milk, flour)
    for item_i, item_j in combinations(all_items, 2):
        city_count = 0   # how many cities show sim >= TAU for this pair
        sims       = []  # collect all per-city similarities (for averaging)

        for city in all_cities:
            # Retrieve the delta vectors for each item in this city
            vi = vectors.get((item_i, city))
            vj = vectors.get((item_j, city))

            # If either item has no vector in this city, skip it
            if vi is None or vj is None:
                continue

            # Vectors may have different lengths (edge months differ);
            # truncate both to the shorter one so they're comparable
            mn  = min(len(vi), len(vj))
            sim = cosine_sim(vi[:mn], vj[:mn])
            sims.append(sim)

            # Does this city "agree" that the pair co-moves?
            if sim >= TAU:
                city_count += 1

        # Store results for this pair
        pc[(item_i, item_j)] = city_count
        pa[(item_i, item_j)] = float(np.mean(sims)) if sims else 0.0

    pair_data[yr] = {'count': pc, 'avg_sim': pa}

    # Summary statistics for this year
    counts_list = list(pc.values())
    print(f"     Pairs agreeing in ≥1 city: {sum(c>0 for c in counts_list)}/{n_pairs}")
    print(f"     Pairs agreeing in all {len(all_cities)} cities: {sum(c==len(all_cities) for c in counts_list)}")
    print(f"     Average cities agreeing per pair: {np.mean(counts_list):.2f}")

# ============================================================
# STEP 7 — BUILD THE NETWORK GRAPH (one per year)
# ============================================================
# Nodes  = items (e.g. "Flour", "Petrol", "Milk")
# Edges  = pairs where at least K cities agreed on co-movement
# Edge attributes stored:
#   weight     → same as city_count (used for edge thickness in charts)
#   avg_sim    → average cosine similarity across all cities
#   city_count → raw number of agreeing cities
print(f"\nBuilding graphs (τ={TAU}, K={K})...")

graphs = {}   # graphs[year] = NetworkX Graph object

for yr in years:
    pc  = pair_data[yr]['count']
    avg = pair_data[yr]['avg_sim']

    G = nx.Graph()   # undirected graph (co-movement is symmetric)

    # Add every item as a node, tagging it with its category and colour
    for item in all_items:
        G.add_node(item,
                   category=item_cat.get(item, 'Unknown'),
                   color=CAT_COLORS.get(item_cat.get(item, ''), '#888888'))

    # Add an edge only if the pair passed the K-city threshold
    for (i, j), cnt in pc.items():
        if cnt >= K:                              # the KEY filter
            G.add_edge(i, j,
                       weight=cnt,               # heavier = more cities agree
                       avg_sim=round(avg[(i,j)],4),
                       city_count=cnt)

    graphs[yr] = G

    # Graph-level statistics
    comps = list(nx.connected_components(G))
    degs  = [d for _, d in G.degree()]
    print(f"  → {yr}: nodes={G.number_of_nodes()}  edges={G.number_of_edges()}  "
          f"density={nx.density(G):.4f}  components={len(comps)}  "
          f"largest={len(max(comps, key=len))}  avgdeg={np.mean(degs):.2f}  "
          f"isolated={sum(1 for d in degs if d==0)}")

# ============================================================
# STEP 8 — CENTRALITY ANALYSIS
# ============================================================
# Centrality measures tell us which items are the most "important"
# or "influential" within the co-movement network.
#
#   Degree centrality    — fraction of other nodes this node connects to.
#                          High degree = item co-moves with MANY others.
#   Closeness centrality — how quickly this node can reach all others.
#                          High closeness = item is near the "centre" of the network.
#   Betweenness centrality — how often this node sits on the shortest path
#                            between two other nodes.
#                            High betweenness = item is a critical "bridge".
print("\nComputing centrality measures...")

centrality = {}   # centrality[year] = DataFrame of all items ranked by centrality

for yr in years:
    G = graphs[yr]

    # Largest connected component (LCC) — closeness and betweenness are only
    # meaningful within a connected subgraph (can't compute path lengths to
    # nodes you can't reach)
    lcc = G.subgraph(max(nx.connected_components(G), key=len)).copy()

    # Compute the three centrality measures
    deg_c  = nx.degree_centrality(G)           # uses the full graph
    clos_c = nx.closeness_centrality(lcc)       # uses LCC only
    betw_c = nx.betweenness_centrality(         # uses LCC only
        lcc, normalized=True, weight='weight')

    # Build a row for every item in the full graph
    rows = []
    for node in G.nodes():
        rows.append({
            'Item':        node,
            'Category':    G.nodes[node]['category'],
            'Degree':      G.degree(node),
            'Degree_C':    round(deg_c.get(node, 0), 4),
            'Closeness_C': round(clos_c.get(node, 0), 4),  # 0 if node is isolated
            'Betw_C':      round(betw_c.get(node, 0), 6),  # 0 if node is isolated
        })

    cent_data = pd.DataFrame(rows)

    # Overall rank = sum of individual ranks (lower rank number = more central)
    # Adding all three rank columns gives a composite "how central overall" score
    cent_data['Overall_Rank'] = (
        cent_data['Degree_C'].rank(ascending=False) +
        cent_data['Closeness_C'].rank(ascending=False) +
        cent_data['Betw_C'].rank(ascending=False)
    )

    # Sort by overall rank so the top items appear first
    cent_data = cent_data.sort_values('Overall_Rank').reset_index(drop=True)
    centrality[yr] = cent_data

    # Print top 5 most central items for this year
    print(f"\n  ─── {yr} Top 5 Most Central Items ───")
    print(f"  {'Item':<45} {'Deg':>6} {'Close':>8} {'Betw':>10}  Category")
    print(f"  {'─'*85}")
    for _, r in cent_data.head(5).iterrows():
        print(f"  {r['Item']:<45} {r['Degree_C']:>6.4f} {r['Closeness_C']:>8.4f} "
              f"{r['Betw_C']:>10.5f}  {r['Category']}")

# ============================================================
# STEP 9 — STABILITY ANALYSIS (which items are central every year?)
# ============================================================
print("\n   Stability: Items in Top 10 across years ")

# Build a set of the top-10 items by centrality for each year
top10 = {yr: set(centrality[yr].head(10)['Item']) for yr in years}

# Items in the top 10 for ALL THREE years (consistently central)
stable = top10['Year1'] & top10['Year2'] & top10['Year3']

# Items in the top 10 for at least TWO of the three years
in_two = ((top10['Year1'] & top10['Year2']) |
          (top10['Year2'] & top10['Year3']) |
          (top10['Year1'] & top10['Year3']))

print(f"  In all 3 years:    {stable or 'None (rankings shifted each year)'}")
print(f"  In at least 2:     {in_two}")

# ============================================================
# STEP 10 — TEMPORAL (YEAR-TO-YEAR) ANALYSIS
# ============================================================
# Track how the network CHANGES between years:
#   new edges  = item pairs that started co-moving
#   lost edges = item pairs that stopped co-moving
#   persistent = edges present in ALL three years (very stable co-movers)
#   transient  = edges present in SOME but not all years
print("\n Temporal analysis...")

def edge_set(G):
    """
    Convert a graph's edge list into a set of frozensets.
    frozenset({u, v}) is unordered, so (A,B) and (B,A) are the same edge.
    This makes set operations (union, intersection, difference) straightforward.
    """
    return set(frozenset([u, v]) for u, v in G.edges())

# Build an edge-set for each year
E = {yr: edge_set(graphs[yr]) for yr in years}

# Year1 → Year2 transitions
new_12  = E['Year2'] - E['Year1']   # edges that appeared in Year2 but not Year1
lost_12 = E['Year1'] - E['Year2']   # edges that existed in Year1 but not Year2

# Year2 → Year3 transitions
new_23  = E['Year3'] - E['Year2']   # edges that appeared in Year3 but not Year2
lost_23 = E['Year2'] - E['Year3']   # edges that existed in Year2 but not Year3

# Persistent = present in Year1 AND Year2 AND Year3 (intersection of all three)
persist   = E['Year1'] & E['Year2'] & E['Year3']

# Transient  = present in at least one year but NOT in all three
transient = (E['Year1'] | E['Year2'] | E['Year3']) - persist

print(f"\n  Year1 → Year2:  +{len(new_12)} new edges,  -{len(lost_12)} lost edges")
print(f"  Year2 → Year3:  +{len(new_23)} new edges,  -{len(lost_23)} lost edges")
print(f"  Persistent edges (all 3 years):  {len(persist)}")
print(f"  Transient edges (not all 3):     {len(transient)}")

# List every persistent pair and note if they're in the same category
print(f"\n  ─── {len(persist)} Persistent Co-Moving Pairs ───")
for edge in persist:
    items = list(edge)
    catA  = item_cat.get(items[0], '?')
    catB  = item_cat.get(items[1], '?')
    same  = '(same cat)' if catA == catB else '(cross-cat)'
    print(f"  {items[0]:<45}  ↔  {items[1]:<45}  {same}")

# ============================================================
# STEP 11 — CATEGORY CONNECTIVITY ANALYSIS
# ============================================================
# For each year, count how many edges connect items WITHIN the
# same category vs BETWEEN different categories.
# A high "between" ratio means price shocks spread across sectors.
print("\n Category connectivity analysis...")

for yr in years:
    G       = graphs[yr]
    within  = 0   # edges where both items share the same category
    between = 0   # edges where items belong to different categories

    for u, v in G.edges():
        if G.nodes[u]['category'] == G.nodes[v]['category']:
            within += 1
        else:
            between += 1

    total = within + between
    print(f"  {yr}:  within-category = {within} ({100*within/total:.0f}%)   "
          f"between-category = {between} ({100*between/total:.0f}%)")

# ============================================================
# STEP 12 — SENSITIVITY ANALYSIS (varying τ and K)
# ============================================================
# How sensitive are our results to the choice of TAU and K?
# We sweep a grid of values and count how many edges each combination
# produces. This tells us if the findings are robust or fragile.
print("\n Sensitivity analysis (varying τ and K)...")

TAU_VALUES = [0.4, 0.5, 0.6, 0.7, 0.8]   # range of cosine similarity thresholds
K_VALUES   = [2, 3, 5, 7, 10]             # range of minimum-city requirements
sens_rows  = []                            # collect rows for a summary DataFrame

for tau in TAU_VALUES:
    for k in K_VALUES:
        for yr in years:
            pc  = pair_data[yr]['count']
            avg = pair_data[yr]['avg_sim']

            # Build a temporary graph with this (tau, k) combination
            Gt = nx.Graph()
            Gt.add_nodes_from(all_items)   # always include all nodes

            for (i, j), cnt in pc.items():
                # Edge condition: average similarity >= tau AND city count >= k
                if avg[(i, j)] >= tau and cnt >= k:
                    Gt.add_edge(i, j, weight=cnt)

            comps = list(nx.connected_components(Gt))

            # Record graph-level stats for this (tau, k, year) combo
            sens_rows.append({
                'tau':        tau,
                'K':          k,
                'Year':       yr,
                'Edges':      Gt.number_of_edges(),
                'Components': len(comps),
                'Largest':    len(max(comps, key=len)) if comps else 0,
                'Density':    round(nx.density(Gt), 4),
            })

sens_data = pd.DataFrame(sens_rows)

# Print a subset of the sensitivity table (Year1 only for brevity)
print(f"\n  Sensitivity table — Year1 only:")
y1s = sens_data[sens_data['Year'] == 'Year1'][['tau', 'K', 'Edges', 'Components', 'Density']]
print(y1s.to_string(index=False))

# ============================================================
# STEP 13 — EXPORT RESULT CSVs
# ============================================================
print("\n Exporting result files...")

# Create the output directory if it doesn't already exist
os.makedirs('output', exist_ok=True)

# Export the centrality ranking table for each year
for yr in years:
    centrality[yr].to_csv(f'output/centrality_{yr}.csv', index=False)
    print(f"  → output/centrality_{yr}.csv")

# Export the full sensitivity analysis table
sens_data.to_csv('output/sensitivity_analysis.csv', index=False)
print(f"  → output/sensitivity_analysis.csv")

# ── Export the top similar item pairs for Year1 ────────────────
# Build a flat list of all pairs with their metrics for Year1
top_pairs_rows = []
for (i, j), cnt in pair_data['Year1']['count'].items():
    top_pairs_rows.append({
        'Item_A':         i,
        'Item_B':         j,
        'Cat_A':          item_cat.get(i, '?'),
        'Cat_B':          item_cat.get(j, '?'),
        'Cities_Agreeing': cnt,
        'Avg_Sim':        round(pair_data['Year1']['avg_sim'][(i, j)], 4),
    })

# Sort so the most strongly co-moving pairs appear at the top
pd.DataFrame(top_pairs_rows)\
  .sort_values('Cities_Agreeing', ascending=False)\
  .to_csv('output/top_similar_pairs_Year1.csv', index=False)
print(f"  → output/top_similar_pairs_Year1.csv")

# ============================================================
# STEP 14 — VISUALISATIONS (Charts 1–7)
# ============================================================
print("\n Generating all charts and network graphs...")

# Human-readable year labels used in chart titles
YEAR_LABELS = {'Year1': '2023-24', 'Year2': '2024-25', 'Year3': '2025-26'}

# ── CHART 1: Centrality bar charts ────────────────────────────
# 3×3 grid: rows = years, columns = centrality measure
# Each sub-chart shows the top-12 items for that measure+year
print("  → Chart 1: Centrality rankings...")
fig, axes = plt.subplots(3, 3, figsize=(24, 18))
fig.suptitle(
    'Centrality Analysis — PBS CPI Item Networks (All 3 Years)',
    fontsize=16, fontweight='bold', y=1.01
)

# Define which measures to show and their axis labels
measures = [
    ('Degree_C',    'Degree Centrality'),
    ('Closeness_C', 'Closeness Centrality'),
    ('Betw_C',      'Betweenness Centrality'),
]

for col, (measure, label) in enumerate(measures):
    for row, yr in enumerate(years):
        ax  = axes[row][col]
        # Get the 12 items with the highest value for this measure
        top = centrality[yr].nlargest(12, measure)
        # Colour each bar by its category
        colors = [CAT_COLORS.get(c, '#888888') for c in top['Category']]
        # Horizontal bar chart (barh) makes long item names readable
        ax.barh(top['Item'], top[measure], color=colors,
                edgecolor='white', linewidth=0.4)
        ax.set_xlabel(label, fontsize=9)
        ax.set_title(f'{YEAR_LABELS[yr]}', fontsize=11, fontweight='bold')
        ax.invert_yaxis()   # highest value at the top
        ax.tick_params(axis='y', labelsize=7)
        ax.grid(axis='x', alpha=0.3)
        ax.spines[['top', 'right']].set_visible(False)

# Add a shared legend at the bottom showing which colour = which category
patches = [mpatches.Patch(color=c, label=cat[:30])
           for cat, c in CAT_COLORS.items()]
fig.legend(handles=patches, loc='lower center', ncol=4, fontsize=8,
           bbox_to_anchor=(0.5, -0.03), title='Item Categories')
plt.tight_layout()
plt.savefig('output/chart1_centrality.png', dpi=150, bbox_inches='tight')

# ── CHART 2: Temporal comparison (3 sub-charts) ───────────────
# Sub-chart A: Total edges per year (bar chart)
# Sub-chart B: Edge gains and losses between consecutive years
# Sub-chart C: Pie chart — persistent vs transient edges
print("  → Chart 2: Temporal analysis...")
fig, axes = plt.subplots(1, 3, figsize=(18, 5))
fig.suptitle('Temporal Evolution of Price Co-Movement Network',
             fontsize=14, fontweight='bold')

yrs_label   = ['2023-24', '2024-25', '2025-26']
edge_counts = [len(E['Year1']), len(E['Year2']), len(E['Year3'])]

# Sub-chart A — total edges per year
bars = axes[0].bar(yrs_label, edge_counts,
                   color=['#2196F3', '#F44336', '#4CAF50'], edgecolor='white')
# Label each bar with its exact value above the bar
for bar, val in zip(bars, edge_counts):
    axes[0].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 2,
                 str(val), ha='center', fontsize=12, fontweight='bold')
axes[0].set_title('Total Edges per Year', fontweight='bold')
axes[0].set_ylabel('Number of Edges')
axes[0].set_ylim(0, max(edge_counts) * 1.2)
axes[0].grid(axis='y', alpha=0.3)
axes[0].spines[['top', 'right']].set_visible(False)

# Sub-chart B — edge flow (new vs lost between years)
flow_labels = ['Y1→Y2\nNew', 'Y1→Y2\nLost', 'Y2→Y3\nNew', 'Y2→Y3\nLost']
flow_vals   = [len(new_12), len(lost_12), len(new_23), len(lost_23)]
flow_colors = ['#4CAF50', '#F44336', '#4CAF50', '#F44336']   # green=new, red=lost
bars2 = axes[1].bar(flow_labels, flow_vals, color=flow_colors, edgecolor='white')
for bar, val in zip(bars2, flow_vals):
    axes[1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
                 str(val), ha='center', fontsize=12, fontweight='bold')
axes[1].set_title('Edge Changes Year to Year', fontweight='bold')
axes[1].grid(axis='y', alpha=0.3)
axes[1].spines[['top', 'right']].set_visible(False)

# Sub-chart C — persistent vs transient pie chart
axes[2].pie([len(persist), len(transient)],
            labels=[f'Persistent\n({len(persist)} pairs)',
                    f'Transient\n({len(transient)} pairs)'],
            colors=['#2196F3', '#FF9800'], autopct='%1.1f%%', startangle=90)
axes[2].set_title('Persistent vs Transient Edges', fontweight='bold')

plt.tight_layout()
plt.savefig('output/chart2_temporal.png', dpi=150, bbox_inches='tight')

# ── CHART 3: Sensitivity heatmap ──────────────────────────────
# For each year, show a τ × K matrix coloured by edge count.
# Hot colours = many edges (loose threshold), cool = few (strict threshold).
print("  → Chart 3: Sensitivity heatmap...")
fig, axes = plt.subplots(1, 3, figsize=(18, 5))
fig.suptitle('Threshold Sensitivity: τ × K — Effect on Edge Count',
             fontsize=13, fontweight='bold')

for idx, yr in enumerate(years):
    ax      = axes[idx]
    data_yr = sens_data[sens_data['Year'] == yr]
    tv = sorted(sens_data['tau'].unique())   # τ values (y-axis)
    kv = sorted(sens_data['K'].unique())     # K values (x-axis)
    mat = np.zeros((len(tv), len(kv)))       # 2D matrix to fill with edge counts

    for i, tau in enumerate(tv):
        for j, k in enumerate(kv):
            row = data_yr[(data_yr['tau'] == tau) & (data_yr['K'] == k)]['Edges']
            mat[i, j] = row.values[0] if len(row) else 0

    # imshow renders the matrix as a colour grid
    im = ax.imshow(mat, cmap='YlOrRd', aspect='auto',
                   vmin=0, vmax=sens_data['Edges'].max())
    ax.set_xticks(range(len(kv)));  ax.set_xticklabels([str(k) for k in kv])
    ax.set_yticks(range(len(tv)));  ax.set_yticklabels([str(t) for t in tv])
    ax.set_xlabel('K (min cities)'); ax.set_ylabel('τ (threshold)')
    ax.set_title(YEAR_LABELS[yr], fontweight='bold')

    # Annotate each cell with its numeric edge count
    for i in range(len(tv)):
        for j in range(len(kv)):
            ax.text(j, i, int(mat[i, j]), ha='center', va='center', fontsize=9)

    plt.colorbar(im, ax=ax, shrink=0.8, label='Edge Count')

plt.tight_layout()
plt.savefig('output/chart3_sensitivity.png', dpi=150, bbox_inches='tight')


# ── CHART 4: Category connectivity (within vs between) ────────
# For each category, compare how many edges stay inside the category
# vs how many cross into a different category.
print("  → Chart 4: Category connectivity...")
fig, axes = plt.subplots(1, 3, figsize=(20, 6))
fig.suptitle('Within vs Between Category Edges per Year',
             fontsize=13, fontweight='bold')

cats  = list(CAT_COLORS.keys())
short = [c[:16] for c in cats]   # truncated labels so they fit on the x-axis

for idx, yr in enumerate(years):
    ax = axes[idx]
    G  = graphs[yr]

    # Count within-category and between-category edges per category
    within_c  = {c: 0 for c in cats}
    between_c = {c: 0 for c in cats}

    for u, v in G.edges():
        cu = G.nodes[u]['category']
        cv = G.nodes[v]['category']
        if cu == cv:
            # Both endpoints are in the same category
            within_c[cu]  = within_c.get(cu, 0) + 1
        else:
            # Endpoints are in different categories — count the edge
            # for BOTH categories (each category "receives" a cross-edge)
            between_c[cu] = between_c.get(cu, 0) + 1
            between_c[cv] = between_c.get(cv, 0) + 1

    # Grouped bar chart: within (blue) and between (orange) side by side
    x = np.arange(len(cats))
    w = 0.35   # bar width
    ax.bar(x - w/2, [within_c.get(c, 0) for c in cats],  w,
           label='Within',  color='#2196F3', alpha=0.85, edgecolor='white')
    ax.bar(x + w/2, [between_c.get(c, 0) for c in cats], w,
           label='Between', color='#FF9800', alpha=0.85, edgecolor='white')
    ax.set_xticks(x)
    ax.set_xticklabels(short, rotation=45, ha='right', fontsize=7)
    ax.set_title(YEAR_LABELS[yr], fontweight='bold')
    ax.set_ylabel('Edge Count')
    ax.legend(fontsize=9)
    ax.grid(axis='y', alpha=0.3)
    ax.spines[['top', 'right']].set_visible(False)

plt.tight_layout()
plt.savefig('output/chart4_categories.png', dpi=150, bbox_inches='tight')

# ── CHART 5: Degree distribution ──────────────────────────────
# A histogram showing how many nodes have each degree value.
# Helps identify whether the network is hub-heavy (power law) or
# evenly connected (random graph).
print("  → Chart 5: Degree distribution...")
fig, axes = plt.subplots(1, 3, figsize=(16, 5))
fig.suptitle('Degree Distribution Across Years', fontsize=13, fontweight='bold')

for idx, yr in enumerate(years):
    ax   = axes[idx]
    G    = graphs[yr]
    degs = [d for _, d in G.degree()]   # list of degree values for all nodes

    ax.hist(degs, bins=15, color='#2196F3', edgecolor='white', alpha=0.85)
    # Add a vertical red dashed line at the mean degree
    ax.axvline(np.mean(degs), color='red', linestyle='--', linewidth=1.5,
               label=f'Mean = {np.mean(degs):.1f}')
    ax.set_title(YEAR_LABELS[yr], fontweight='bold')
    ax.set_xlabel('Node Degree')
    ax.set_ylabel('Frequency')
    ax.legend(fontsize=9)
    ax.grid(alpha=0.3)
    ax.spines[['top', 'right']].set_visible(False)

plt.tight_layout()
plt.savefig('output/chart5_degree.png', dpi=150, bbox_inches='tight')


# ── CHART 6: Full network graph (one per year) ────────────────
# Dark background, spring-force layout, nodes coloured by category,
# node size proportional to degree, edge thickness proportional to
# the number of agreeing cities (edge weight).
print("  → Chart 6: Network graphs (one per year)...")

for yr in years:
    G    = graphs[yr]
    degs = dict(G.degree())
    max_deg = max(degs.values()) if degs else 1   # avoid division by zero

    fig, ax = plt.subplots(figsize=(16, 12))
    ax.set_facecolor('#0F1117')          # dark background for the plot area
    fig.patch.set_facecolor('#0F1117')   # dark background for the figure border

    # Spring layout: nodes repel each other but edges act as springs.
    # k controls the ideal edge length; seed=42 makes it reproducible.
    pos = nx.spring_layout(G, k=0.55, seed=42, weight='weight')

    # Draw edges — thickness scales with edge weight (more cities = thicker)
    edge_weights = [G[u][v].get('weight', 1) for u, v in G.edges()]
    max_w = max(edge_weights) if edge_weights else 1
    nx.draw_networkx_edges(
        G, pos, ax=ax,
        width=[0.5 + 2.5 * (w / max_w) for w in edge_weights],
        edge_color='#FFFFFF', alpha=0.18   # semi-transparent white
    )

    # Draw nodes — colour by category, size by degree
    node_colors = [G.nodes[n].get('color', '#888888') for n in G.nodes()]
    node_sizes  = [120 + 900 * (degs[n] / max_deg) for n in G.nodes()]
    nx.draw_networkx_nodes(G, pos, ax=ax,
                           node_color=node_colors, node_size=node_sizes,
                           alpha=0.92, linewidths=0.5,
                           edgecolors='white')

    # Label nodes that have at least one connection (skip isolated nodes)
    labels = {n: n if degs[n] > 0 else '' for n in G.nodes()}
    nx.draw_networkx_labels(G, pos, labels=labels, ax=ax,
                            font_size=6, font_color='white', font_weight='bold')

    # Category colour legend
    legend_patches = [mpatches.Patch(color=c, label=cat)
                      for cat, c in CAT_COLORS.items()]
    ax.legend(handles=legend_patches, loc='upper left', fontsize=8,
              facecolor='#1a1a2e', edgecolor='#444', labelcolor='white')

    ax.set_title(
        f'Item Price Co-Movement Network — {YEAR_LABELS[yr]}\n'
        f'Nodes: {G.number_of_nodes()}  |  Edges: {G.number_of_edges()}  |  '
        f'τ = {TAU}  |  K = {K}  |  Node size ∝ degree',
        color='white', fontsize=13, fontweight='bold', pad=14
    )
    ax.axis('off')
    plt.tight_layout()
    plt.savefig(f'output/network_{yr}.png', dpi=150, bbox_inches='tight',
                facecolor='#0F1117')
    print(f"     Saved network_{yr}.png")

# ── CHART 7: Two weighting schemes side by side (Year1 only) ──
# Compare what the Year1 network looks like when edge thickness is
# driven by (a) city count vs (b) average cosine similarity.
print("  → Chart 7: Weighting scheme comparison (Year1)...")

G   = graphs['Year1']
pos = nx.spring_layout(G, k=0.55, seed=42, weight='weight')   # same layout for both

fig, axes = plt.subplots(1, 2, figsize=(22, 10))
fig.patch.set_facecolor('#0F1117')

# Each tuple: (axis, panel title, edge attribute key, subtitle description)
for ax, scheme, key, scheme_label in [
    (axes[0], 'City Count Weighting',         'city_count', 'w = number of agreeing cities (3–17)'),
    (axes[1], 'Average Similarity Weighting', 'avg_sim',    'w = average cosine similarity (0–1)'),
]:
    ax.set_facecolor('#0F1117')

    # Get the chosen edge attribute for thickness scaling
    weights = [G[u][v].get(key, 1) for u, v in G.edges()]
    max_w   = max(weights) if weights else 1

    nx.draw_networkx_edges(G, pos, ax=ax,
                           width=[0.5 + 3 * (w/max_w) for w in weights],
                           edge_color='#FFFFFF', alpha=0.2)

    degs        = dict(G.degree())
    node_colors = [G.nodes[n].get('color', '#888') for n in G.nodes()]
    node_sizes  = [100 + 800 * (degs[n]/max(degs.values())) for n in G.nodes()]

    nx.draw_networkx_nodes(G, pos, ax=ax, node_color=node_colors,
                           node_size=node_sizes, alpha=0.9,
                           edgecolors='white', linewidths=0.5)

    labels = {n: n if degs[n] > 0 else '' for n in G.nodes()}
    nx.draw_networkx_labels(G, pos, labels=labels, ax=ax,
                            font_size=6, font_color='white', font_weight='bold')

    ax.set_title(f'Weighting Scheme: {scheme}\n{scheme_label}',
                 color='white', fontsize=12, fontweight='bold', pad=10)
    ax.axis('off')

fig.suptitle(
    f'Two Weighting Schemes — Year 1 (2023-24)  |  '
    f'{G.number_of_nodes()} nodes  {G.number_of_edges()} edges',
    color='white', fontsize=14, fontweight='bold'
)
plt.tight_layout()
plt.savefig('output/chart7_weighting_schemes.png', dpi=150,
            bbox_inches='tight', facecolor='#0F1117')

# ============================================================
# STEP 15 — FINAL SUMMARY PRINTOUT
# ============================================================
# Human-readable narrative summary of the key findings
print(f"""
 THE DATA WE USED
   prices of {len(all_items)} everyday items(bread, milk, petrol, eggs, flour...)
   across {len(all_cities)} cities in Pakistan
   over 3 years — from April 2023 to March 2026
   i.e., {len(data):,} price records in total!

   OUR FINDINGS (Year by Year)
   items as dots, lines between dots if their prices go up/down together.

   Year 1 (2023-24): {len(E['Year1'])} pairs of items moved together
   Year 2 (2024-25): {len(E['Year2'])} pairs moved together  (big drop)
   Year 3 (2025-26): {len(E['Year3'])} pairs moved together  (slight recovery)

      2023-24 : peak inflation 
      By 2024-25, things stabilize (items were moving in sync.)

   Year 1 TO Year 2: {len(new_12)} new connections formed, {len(lost_12)} old ones broke
   Year 2 TO Year 3: {len(new_23)} new connections formed, {len(lost_23)} old ones broke

   {len(persist)} pairs stayed connected ALL 3 years
   (these items ALWAYS move together )

   {len(transient)} pairs only connected sometimes
   (these items move together )

 MOST INFLUENCIAL ITEMS
   2023-24: Cooked Daal       
   2024-25: Mustard Oil      
   2025-26: Beef & Petrol    

  PRICE CHANGES  WITHIN SAME CATEGORY
   70-75% of connections were CROSS-category
   (when flour goes up, petrol might too )
   price shocks spread everywhere

 
""")

print(f"  All output files saved ")
