import pandas as pd
import numpy as np
import networkx as nx
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from itertools import combinations
import warnings
import os
import sys

warnings.filterwarnings('ignore')
#load file
print("\nFile loading")
file_name = 'data.csv'
if not os.path.exists(file_name):
    print(f"\nFile not found — '{file_name}'")
    sys.exit(1)
print(f"  → Found: {file_name}")
data = pd.read_csv(file_name)
print(f"  → Loaded {len(data):,} rows")
print(f"  → Columns: {list(data.columns)}")
#price change vectors
print("\nprice-change vectors (Preprocessing)")

TAU = 0.6   # threshold for Cosine similarity 
K   = 3     # Minimum number of cities that must agree   

#colours 
CAT_COLORS = {
    'Cereals & Bread':                    '#2196F3',
    'Meat & Poultry':                     '#F44336',
    'Dairy, Eggs & Fats':                 '#FF9800',
    'Fruits, Pulses & Vegetables':        '#4CAF50',
    'Sugar, Condiments & Prepared Food':  '#9C27B0',
    'Clothing, Footwear & Energy':        '#00BCD4',
    'Fuel, Transport & Misc':             '#795548',
}

#  Cleaning prices //for the prives missing in pbs links
data['price'] = pd.to_numeric(data['price'], errors='coerce')
missing_before = data['price'].isna().sum()
data = data.sort_values(['item', 'city', 'month_year']).reset_index(drop=True)
for i in range(len(data)):
    if pd.isna(data.at[i, 'price']):
        curr_group = (data.at[i, 'item'], data.at[i, 'city'])
        prev_val = np.nan
        for j in range(i - 1, -1, -1):
            if (data.at[j, 'item'], data.at[j, 'city']) == curr_group:
                if not pd.isna(data.at[j, 'price']):
                    prev_val = data.at[j, 'price']
                    break
            else:
                break
        next_val = np.nan
        for j in range(i + 1, len(data)):
            if (data.at[j, 'item'], data.at[j, 'city']) == curr_group:
                if not pd.isna(data.at[j, 'price']):
                    next_val = data.at[j, 'price']
                    break
            else:
                break
        if not pd.isna(prev_val) and not pd.isna(next_val):
            data.at[i, 'price'] = round((prev_val + next_val) / 2.0, 2)
        elif not pd.isna(prev_val):
            data.at[i, 'price'] = prev_val
        elif not pd.isna(next_val):
            data.at[i, 'price'] = next_val
data['price'] = data.groupby(['item', 'month_year'])['price'].transform(
    lambda s: s.fillna(round(s.mean(), 2))
)
missing_after = data['price'].isna().sum()
print(f"  → Missing prices: {missing_before} found, {missing_before - missing_after} filled by average of previous and next")

#  get dimensions 
all_items = sorted(data['item'].unique().tolist())
all_cities = sorted(data['city'].unique().tolist())
years = ['Year1', 'Year2', 'Year3']
item_cat = dict(zip(data['item'], data['category']))

print(f"  → Items: {len(all_items)}   Cities: {len(all_cities)}   Years: {len(years)}")
print(f"  → Year labels: {sorted(data['year_label'].unique().tolist())}")
yearly_vectors = {yr: {} for yr in years}

for yr in years:
    sub = data[data['year_label'] == yr].copy()
    months_sorted = sorted(sub['month_year'].unique())

    for item in all_items:
        item_data = sub[sub['item'] == item]
        pivot = item_data.pivot_table(
            index='month_year', columns='city', values='price', aggfunc='mean')
        pivot = pivot.reindex(months_sorted).ffill().bfill()

        for city in all_cities:
            if city not in pivot.columns:
                continue
            prices = pivot[city].values.astype(float)
            if len(prices) < 2:
                continue
            deltas = np.diff(prices)   
            if np.linalg.norm(deltas) > 0:
                yearly_vectors[yr][(item, city)] = deltas

    n_vec = len(yearly_vectors[yr])
    sample_len = len(list(yearly_vectors[yr].values())[0]) if yearly_vectors[yr] else 0
    print(f"  → {yr}: {n_vec} vectors, each length {sample_len}")

#cosine similarity
print("\ncalculating cosine similarity for all item pairs...")

def cosine_sim(v1, v2):
    """
    Cosine similarity — Project Section 4 formula:
        sim(y,c)(i,j) = v(i) · v(j) / (||v(i)|| × ||v(j)||)
    Returns 0.0 if either vector is zero-norm.
    """
    n1, n2 = np.linalg.norm(v1), np.linalg.norm(v2)
    if n1 == 0 or n2 == 0:
        return 0.0
    return float(np.dot(v1, v2) / (n1 * n2))

# pair_data[yr][(i,j)] = {'count': int, 'avg_sim': float}
pair_data = {}
for yr in years:
    vectors = yearly_vectors[yr]
    pc, pa = {}, {}
    n_pairs = len(all_items) * (len(all_items) - 1) // 2
    print(f"  → {yr}: {n_pairs} pairs × {len(all_cities)} cities...")

    for item_i, item_j in combinations(all_items, 2):
        city_count = 0
        sims = []
        for city in all_cities:
            vi = vectors.get((item_i, city))
            vj = vectors.get((item_j, city))
            if vi is None or vj is None:
                continue
            mn = min(len(vi), len(vj))
            sim = cosine_sim(vi[:mn], vj[:mn])
            sims.append(sim)
            if sim >= TAU:
                city_count += 1

        pc[(item_i, item_j)] = city_count
        pa[(item_i, item_j)] = float(np.mean(sims)) if sims else 0.0

    pair_data[yr] = {'count': pc, 'avg_sim': pa}
    counts_list = list(pc.values())
    print(f"     Pairs agreeing in ≥1 city: {sum(c>0 for c in counts_list)}/{n_pairs}")
    print(f"     Pairs agreeing in all {len(all_cities)} cities: {sum(c==len(all_cities) for c in counts_list)}")
    print(f"     Average cities agreeing per pair: {np.mean(counts_list):.2f}")

#buildiong graph
print(f"\nBuilding graphs (τ={TAU}, K={K})...")
graphs = {}  
for yr in years:
    pc = pair_data[yr]['count']
    avg = pair_data[yr]['avg_sim']

    G = nx.Graph()
    for item in all_items:
        G.add_node(item, category=item_cat.get(item, 'Unknown'),
                   color=CAT_COLORS.get(item_cat.get(item, ''), '#888888'))
    for (i, j), cnt in pc.items():
        if cnt >= K:                              
            G.add_edge(i, j,
                       weight=cnt,               
                       avg_sim=round(avg[(i,j)],4),
                       city_count=cnt)
    graphs[yr] = G
    comps = list(nx.connected_components(G))
    degs  = [d for _, d in G.degree()]
    print(f"  → {yr}: nodes={G.number_of_nodes()}  edges={G.number_of_edges()}  "
          f"density={nx.density(G):.4f}  components={len(comps)}  "
          f"largest={len(max(comps, key=len))}  avgdeg={np.mean(degs):.2f}  "
          f"isolated={sum(1 for d in degs if d==0)}")

#centrality analysis
print("\nComputing centrality measures...")
centrality = {}  
for yr in years:
    G   = graphs[yr]
    lcc = G.subgraph(max(nx.connected_components(G), key=len)).copy()
    deg_c  = nx.degree_centrality(G)           
    clos_c = nx.closeness_centrality(lcc)       
    betw_c = nx.betweenness_centrality(       
        lcc, normalized=True, weight='weight')
    rows = []
    for node in G.nodes():
        rows.append({
            'Item':        node,
            'Category':    G.nodes[node]['category'],
            'Degree':      G.degree(node),
            'Degree_C':    round(deg_c.get(node, 0), 4),
            'Closeness_C': round(clos_c.get(node, 0), 4),
            'Betw_C':      round(betw_c.get(node, 0), 6),
        })
    cent_data = pd.DataFrame(rows)
    cent_data['Overall_Rank'] = (
        cent_data['Degree_C'].rank(ascending=False) +
        cent_data['Closeness_C'].rank(ascending=False) +
        cent_data['Betw_C'].rank(ascending=False)
    )
    cent_data = cent_data.sort_values('Overall_Rank').reset_index(drop=True)
    centrality[yr] = cent_data
    print(f"\n  ─── {yr} Top 5 Most Central Items ───")
    print(f"  {'Item':<45} {'Deg':>6} {'Close':>8} {'Betw':>10}  Category")
    print(f"  {'─'*85}")
    for _, r in cent_data.head(5).iterrows():
        print(f"  {r['Item']:<45} {r['Degree_C']:>6.4f} {r['Closeness_C']:>8.4f} "
              f"{r['Betw_C']:>10.5f}  {r['Category']}")

#  Stability across years 
print("\n   Stability: Items in Top 10 across years ")
top10 = {yr: set(centrality[yr].head(10)['Item']) for yr in years}
stable = top10['Year1'] & top10['Year2'] & top10['Year3']
in_two = ((top10['Year1'] & top10['Year2']) |
          (top10['Year2'] & top10['Year3']) |
          (top10['Year1'] & top10['Year3']))
print(f"  In all 3 years:    {stable or 'None (rankings shifted each year)'}")
print(f"  In at least 2:     {in_two}")

#temporal analysis
print("\n Temporal analysis...")

def edge_set(G):
    return set(frozenset([u, v]) for u, v in G.edges())
E = {yr: edge_set(graphs[yr]) for yr in years}
new_12   = E['Year2'] - E['Year1']
lost_12  = E['Year1'] - E['Year2']
new_23   = E['Year3'] - E['Year2']
lost_23  = E['Year2'] - E['Year3']
persist  = E['Year1'] & E['Year2'] & E['Year3']
transient= (E['Year1'] | E['Year2'] | E['Year3']) - persist
print(f"\n  Year1 → Year2:  +{len(new_12)} new edges,  -{len(lost_12)} lost edges")
print(f"  Year2 → Year3:  +{len(new_23)} new edges,  -{len(lost_23)} lost edges")
print(f"  Persistent edges (all 3 years):  {len(persist)}")
print(f"  Transient edges (not all 3):     {len(transient)}")
print(f"\n  ─── {len(persist)} Persistent Co-Moving Pairs ───")
for edge in persist:
    items = list(edge)
    catA  = item_cat.get(items[0], '?')
    catB  = item_cat.get(items[1], '?')
    same  = '(same cat)' if catA == catB else '(cross-cat)'
    print(f"  {items[0]:<45}  ↔  {items[1]:<45}  {same}")
#category connectivity
print("\n Category connectivity analysis...")

for yr in years:
    G = graphs[yr]
    within = 0
    between = 0
    for u, v in G.edges():
        if G.nodes[u]['category'] == G.nodes[v]['category']:
            within += 1
        else:
            between += 1
    total = within + between
    print(f"  {yr}:  within-category = {within} ({100*within/total:.0f}%)   "
          f"between-category = {between} ({100*between/total:.0f}%)")

#sensitivityu analysis
print("\n Sensitivity analysis (varying τ and K)...")
TAU_VALUES = [0.4, 0.5, 0.6, 0.7, 0.8]
K_VALUES   = [2, 3, 5, 7, 10]
sens_rows  = []

for tau in TAU_VALUES:
    for k in K_VALUES:
        for yr in years:
            pc  = pair_data[yr]['count']
            avg = pair_data[yr]['avg_sim']

            Gt = nx.Graph()
            Gt.add_nodes_from(all_items)
            for (i, j), cnt in pc.items():
                if avg[(i, j)] >= tau and cnt >= k:
                    Gt.add_edge(i, j, weight=cnt)

            comps = list(nx.connected_components(Gt))
            sens_rows.append({
                'tau': tau, 'K': k, 'Year': yr,
                'Edges':      Gt.number_of_edges(),
                'Components': len(comps),
                'Largest':    len(max(comps, key=len)) if comps else 0,
                'Density':    round(nx.density(Gt), 4),
            })

sens_data = pd.DataFrame(sens_rows)
print(f"\n  Sensitivity table — Year1 only:")
y1s = sens_data[sens_data['Year'] == 'Year1'][['tau', 'K', 'Edges', 'Components', 'Density']]
print(y1s.to_string(index=False))
#export csv
print("\n Exporting result files...")
os.makedirs('output', exist_ok=True)
for yr in years:
    centrality[yr].to_csv(f'output/centrality_{yr}.csv', index=False)
    print(f"  → output/centrality_{yr}.csv")
sens_data.to_csv('output/sensitivity_analysis.csv', index=False)
print(f"  → output/sensitivity_analysis.csv")
# Top similar pairs
top_pairs_rows = []
for (i, j), cnt in pair_data['Year1']['count'].items():
    top_pairs_rows.append({
        'Item_A': i, 'Item_B': j,
        'Cat_A':  item_cat.get(i, '?'), 'Cat_B': item_cat.get(j, '?'),
        'Cities_Agreeing': cnt,
        'Avg_Sim': round(pair_data['Year1']['avg_sim'][(i, j)], 4),
    })
pd.DataFrame(top_pairs_rows)\
  .sort_values('Cities_Agreeing', ascending=False)\
  .to_csv('output/top_similar_pairs_Year1.csv', index=False)
print(f"  → output/top_similar_pairs_Year1.csv")

#all visualizations
print("\n Generating all charts and network graphs...")
YEAR_LABELS = {'Year1': '2023-24', 'Year2': '2024-25', 'Year3': '2025-26'}
#  CHART 1: Centrality bar charts  
print("  → Chart 1: Centrality rankings...")
fig, axes = plt.subplots(3, 3, figsize=(24, 18))
fig.suptitle(
    'Centrality Analysis — PBS CPI Item Networks (All 3 Years)',
    fontsize=16, fontweight='bold', y=1.01
)
measures = [
    ('Degree_C',    'Degree Centrality'),
    ('Closeness_C', 'Closeness Centrality'),
    ('Betw_C',      'Betweenness Centrality'),
]
for col, (measure, label) in enumerate(measures):
    for row, yr in enumerate(years):
        ax  = axes[row][col]
        top = centrality[yr].nlargest(12, measure)
        colors = [CAT_COLORS.get(c, '#888888') for c in top['Category']]
        ax.barh(top['Item'], top[measure], color=colors,
                edgecolor='white', linewidth=0.4)
        ax.set_xlabel(label, fontsize=9)
        ax.set_title(f'{YEAR_LABELS[yr]}', fontsize=11, fontweight='bold')
        ax.invert_yaxis()
        ax.tick_params(axis='y', labelsize=7)
        ax.grid(axis='x', alpha=0.3)
        ax.spines[['top', 'right']].set_visible(False)
patches = [mpatches.Patch(color=c, label=cat[:30])
           for cat, c in CAT_COLORS.items()]
fig.legend(handles=patches, loc='lower center', ncol=4, fontsize=8,
           bbox_to_anchor=(0.5, -0.03), title='Item Categories')
plt.tight_layout()
plt.savefig('output/chart1_centrality.png', dpi=150, bbox_inches='tight')
#  CHART 2: Temporal comparison 
print("  → Chart 2: Temporal analysis...")
fig, axes = plt.subplots(1, 3, figsize=(18, 5))
fig.suptitle('Temporal Evolution of Price Co-Movement Network',
             fontsize=14, fontweight='bold')
yrs_label = ['2023-24', '2024-25', '2025-26']
edge_counts = [len(E['Year1']), len(E['Year2']), len(E['Year3'])]
bars = axes[0].bar(yrs_label, edge_counts,
                   color=['#2196F3', '#F44336', '#4CAF50'], edgecolor='white')
for bar, val in zip(bars, edge_counts):
    axes[0].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 2,
                 str(val), ha='center', fontsize=12, fontweight='bold')
axes[0].set_title('Total Edges per Year', fontweight='bold')
axes[0].set_ylabel('Number of Edges')
axes[0].set_ylim(0, max(edge_counts) * 1.2)
axes[0].grid(axis='y', alpha=0.3)
axes[0].spines[['top', 'right']].set_visible(False)

flow_labels = ['Y1→Y2\nNew', 'Y1→Y2\nLost', 'Y2→Y3\nNew', 'Y2→Y3\nLost']
flow_vals   = [len(new_12), len(lost_12), len(new_23), len(lost_23)]
flow_colors = ['#4CAF50', '#F44336', '#4CAF50', '#F44336']
bars2 = axes[1].bar(flow_labels, flow_vals, color=flow_colors, edgecolor='white')
for bar, val in zip(bars2, flow_vals):
    axes[1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
                 str(val), ha='center', fontsize=12, fontweight='bold')
axes[1].set_title('Edge Changes Year to Year', fontweight='bold')
axes[1].grid(axis='y', alpha=0.3)
axes[1].spines[['top', 'right']].set_visible(False)

axes[2].pie([len(persist), len(transient)],
            labels=[f'Persistent\n({len(persist)} pairs)',
                    f'Transient\n({len(transient)} pairs)'],
            colors=['#2196F3', '#FF9800'], autopct='%1.1f%%', startangle=90)
axes[2].set_title('Persistent vs Transient Edges', fontweight='bold')

plt.tight_layout()
plt.savefig('output/chart2_temporal.png', dpi=150, bbox_inches='tight')

#  CHART 3: Sensitivity heatmap 
print("  → Chart 3: Sensitivity heatmap...")
fig, axes = plt.subplots(1, 3, figsize=(18, 5))
fig.suptitle('Threshold Sensitivity: τ × K — Effect on Edge Count',
             fontsize=13, fontweight='bold')
for idx, yr in enumerate(years):
    ax    = axes[idx]
    data_yr = sens_data[sens_data['Year'] == yr]
    tv    = sorted(sens_data['tau'].unique())
    kv    = sorted(sens_data['K'].unique())
    mat   = np.zeros((len(tv), len(kv)))
    for i, tau in enumerate(tv):
        for j, k in enumerate(kv):
            row = data_yr[(data_yr['tau'] == tau) & (data_yr['K'] == k)]['Edges']
            mat[i, j] = row.values[0] if len(row) else 0
    im = ax.imshow(mat, cmap='YlOrRd', aspect='auto',
                   vmin=0, vmax=sens_data['Edges'].max())
    ax.set_xticks(range(len(kv)));  ax.set_xticklabels([str(k) for k in kv])
    ax.set_yticks(range(len(tv)));  ax.set_yticklabels([str(t) for t in tv])
    ax.set_xlabel('K (min cities)'); ax.set_ylabel('τ (threshold)')
    ax.set_title(YEAR_LABELS[yr], fontweight='bold')
    for i in range(len(tv)):
        for j in range(len(kv)):
            ax.text(j, i, int(mat[i, j]), ha='center', va='center', fontsize=9)
    plt.colorbar(im, ax=ax, shrink=0.8, label='Edge Count')
plt.tight_layout()
plt.savefig('output/chart3_sensitivity.png', dpi=150, bbox_inches='tight')


#  CHART 4: Category connectivity 
print("  → Chart 4: Category connectivity...")
fig, axes = plt.subplots(1, 3, figsize=(20, 6))
fig.suptitle('Within vs Between Category Edges per Year',
             fontsize=13, fontweight='bold')
cats  = list(CAT_COLORS.keys())
short = [c[:16] for c in cats]
for idx, yr in enumerate(years):
    ax = axes[idx]
    G  = graphs[yr]
    within_c  = {c: 0 for c in cats}
    between_c = {c: 0 for c in cats}
    for u, v in G.edges():
        cu = G.nodes[u]['category']
        cv = G.nodes[v]['category']
        if cu == cv:
            within_c[cu]  = within_c.get(cu, 0) + 1
        else:
            between_c[cu] = between_c.get(cu, 0) + 1
            between_c[cv] = between_c.get(cv, 0) + 1
    x = np.arange(len(cats))
    w = 0.35
    ax.bar(x - w/2, [within_c.get(c, 0) for c in cats],  w,
           label='Within',  color='#2196F3', alpha=0.85, edgecolor='white')
    ax.bar(x + w/2, [between_c.get(c, 0) for c in cats], w,
           label='Between', color='#FF9800', alpha=0.85, edgecolor='white')
    ax.set_xticks(x)
    ax.set_xticklabels(short, rotation=45, ha='right', fontsize=7)
    ax.set_title(YEAR_LABELS[yr], fontweight='bold')
    ax.set_ylabel('Edge Count')
    ax.legend(fontsize=9)
    ax.grid(axis='y', alpha=0.3)
    ax.spines[['top', 'right']].set_visible(False)
plt.tight_layout()
plt.savefig('output/chart4_categories.png', dpi=150, bbox_inches='tight')

#  CHART 5: Degree distribution 
print("  → Chart 5: Degree distribution...")
fig, axes = plt.subplots(1, 3, figsize=(16, 5))
fig.suptitle('Degree Distribution Across Years', fontsize=13, fontweight='bold')
for idx, yr in enumerate(years):
    ax   = axes[idx]
    G    = graphs[yr]
    degs = [d for _, d in G.degree()]
    ax.hist(degs, bins=15, color='#2196F3', edgecolor='white', alpha=0.85)
    ax.axvline(np.mean(degs), color='red', linestyle='--', linewidth=1.5,
               label=f'Mean = {np.mean(degs):.1f}')
    ax.set_title(YEAR_LABELS[yr], fontweight='bold')
    ax.set_xlabel('Node Degree')
    ax.set_ylabel('Frequency')
    ax.legend(fontsize=9)
    ax.grid(alpha=0.3)
    ax.spines[['top', 'right']].set_visible(False)
plt.tight_layout()
plt.savefig('output/chart5_degree.png', dpi=150, bbox_inches='tight')


#  CHART 6: Network graphs 
print("  → Chart 6: Network graphs (one per year)...")
for yr in years:
    G    = graphs[yr]
    degs = dict(G.degree())
    max_deg = max(degs.values()) if degs else 1

    fig, ax = plt.subplots(figsize=(16, 12))
    ax.set_facecolor('#0F1117')
    fig.patch.set_facecolor('#0F1117')

    pos = nx.spring_layout(G, k=0.55, seed=42, weight='weight')

    # Draw edges
    edge_weights = [G[u][v].get('weight', 1) for u, v in G.edges()]
    max_w = max(edge_weights) if edge_weights else 1
    nx.draw_networkx_edges(
        G, pos, ax=ax,
        width=[0.5 + 2.5 * (w / max_w) for w in edge_weights],
        edge_color='#FFFFFF', alpha=0.18
    )

    # Draw nodes coloured by category
    node_colors = [G.nodes[n].get('color', '#888888') for n in G.nodes()]
    node_sizes  = [120 + 900 * (degs[n] / max_deg) for n in G.nodes()]
    nx.draw_networkx_nodes(G, pos, ax=ax,
                           node_color=node_colors, node_size=node_sizes,
                           alpha=0.92, linewidths=0.5,
                           edgecolors='white')

    # Label connected nodes
    labels = {n: n if degs[n] > 0 else '' for n in G.nodes()}
    nx.draw_networkx_labels(G, pos, labels=labels, ax=ax,
                            font_size=6, font_color='white', font_weight='bold')

    # Legend
    legend_patches = [mpatches.Patch(color=c, label=cat)
                      for cat, c in CAT_COLORS.items()]
    ax.legend(handles=legend_patches, loc='upper left', fontsize=8,
              facecolor='#1a1a2e', edgecolor='#444', labelcolor='white')

    ax.set_title(
        f'Item Price Co-Movement Network — {YEAR_LABELS[yr]}\n'
        f'Nodes: {G.number_of_nodes()}  |  Edges: {G.number_of_edges()}  |  '
        f'τ = {TAU}  |  K = {K}  |  Node size ∝ degree',
        color='white', fontsize=13, fontweight='bold', pad=14
    )
    ax.axis('off')
    plt.tight_layout()
    plt.savefig(f'output/network_{yr}.png', dpi=150, bbox_inches='tight',
                facecolor='#0F1117')
    
    print(f"     Saved network_{yr}.png")

#  CHART 7: Two weighting schemes side by side 
print("  → Chart 7: Weighting scheme comparison (Year1)...")
G = graphs['Year1']
pos = nx.spring_layout(G, k=0.55, seed=42, weight='weight')

fig, axes = plt.subplots(1, 2, figsize=(22, 10))
fig.patch.set_facecolor('#0F1117')

for ax, scheme, key, scheme_label in [
    (axes[0], 'City Count Weighting',      'city_count', 'w = number of agreeing cities (3–17)'),
    (axes[1], 'Average Similarity Weighting', 'avg_sim', 'w = average cosine similarity (0–1)'),
]:
    ax.set_facecolor('#0F1117')
    weights = [G[u][v].get(key, 1) for u, v in G.edges()]
    max_w   = max(weights) if weights else 1
    nx.draw_networkx_edges(G, pos, ax=ax,
                           width=[0.5 + 3 * (w/max_w) for w in weights],
                           edge_color='#FFFFFF', alpha=0.2)
    degs       = dict(G.degree())
    node_colors = [G.nodes[n].get('color', '#888') for n in G.nodes()]
    node_sizes  = [100 + 800 * (degs[n]/max(degs.values())) for n in G.nodes()]
    nx.draw_networkx_nodes(G, pos, ax=ax, node_color=node_colors,
                           node_size=node_sizes, alpha=0.9,
                           edgecolors='white', linewidths=0.5)
    labels = {n: n if degs[n] > 0 else '' for n in G.nodes()}
    nx.draw_networkx_labels(G, pos, labels=labels, ax=ax,
                            font_size=6, font_color='white', font_weight='bold')
    ax.set_title(f'Weighting Scheme: {scheme}\n{scheme_label}',
                 color='white', fontsize=12, fontweight='bold', pad=10)
    ax.axis('off')

fig.suptitle(
    f'Two Weighting Schemes — Year 1 (2023-24)  |  '
    f'{G.number_of_nodes()} nodes  {G.number_of_edges()} edges',
    color='white', fontsize=14, fontweight='bold'
)
plt.tight_layout()
plt.savefig('output/chart7_weighting_schemes.png', dpi=150,
            bbox_inches='tight', facecolor='#0F1117')

#final summary printing
print(f"""
 THE DATA WE USED
   prices of {len(all_items)} everyday items(bread, milk, petrol, eggs, flour...)
   across {len(all_cities)} cities in Pakistan
   over 3 years — from April 2023 to March 2026
   i.e., {len(data):,} price records in total!

   OUR FINDINGS (Year by Year)
   items as dots, lines between dots if their prices go up/down together.

   Year 1 (2023-24): {len(E['Year1'])} pairs of items moved together
   Year 2 (2024-25): {len(E['Year2'])} pairs moved together  (big drop)
   Year 3 (2025-26): {len(E['Year3'])} pairs moved together  (slight recovery)

      2023-24 : peak inflation 
      By 2024-25, things stabilize (items were moving in sync.)

   Year 1 TO Year 2: {len(new_12)} new connections formed, {len(lost_12)} old ones broke
   Year 2 TO Year 3: {len(new_23)} new connections formed, {len(lost_23)} old ones broke

   {len(persist)} pairs stayed connected ALL 3 years
   (these items ALWAYS move together )

   {len(transient)} pairs only connected sometimes
   (these items move together )

 MOST INFLUENCIAL ITEMS
   2023-24: Cooked Daal       
   2024-25: Mustard Oil      
   2025-26: Beef & Petrol    

  PRICE CHANGES  WITHIN SAME CATEGORY
   70-75% of connections were CROSS-category
   (when flour goes up, petrol might too )
   price shocks spread everywhere

 
""")

print(f"  All output files saved ")
